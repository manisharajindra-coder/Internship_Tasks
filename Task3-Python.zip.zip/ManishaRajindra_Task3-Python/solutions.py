def word_frequency(sentence):
    words = sentence.split()
    frequency_dict = {}

    for word in words:
        frequency_dict[word] = frequency_dict.get(word, 0) + 1

    return frequency_dict



# Q2. Find the frequency of each character in a word
def char_frequency(word):
    frequency_dict = {}
    for char in word:
        frequency_dict[char] = frequency_dict.get(char, 0) + 1
    return frequency_dict


# Q3. Find the first non-repeating character

def first_non_repeating_char(word):
    char_count = {}
    for char in word:
        char_count[char] = char_count.get(char, 0) + 1

    for char in word:
        if char_count[char] == 1:
            return char
    return None


# Q4. Check whether two strings are anagrams

def are_anagrams(s1, s2):
    if len(s1) != len(s2):
        return False
    return sorted(s1) == sorted(s2)


# Q5. Find the first repeating character

def first_repeating_char(word):
    seen = set()

    for char in word:
        if char in seen:
            return char
        seen.add(char)

    return None


# Q6. Move all zeros to the end

def move_zeros(numbers):
    non_zeros = []

    for num in numbers:
        if num != 0:
            non_zeros.append(num)

    zero_count = len(numbers) - len(non_zeros)

    return non_zeros + [0] * zero_count

# Q7. Find the second-highest number
def second_highest(numbers):
    unique_numbers = list(set(numbers))

    if len(unique_numbers) < 2:
        return None

    unique_numbers.sort(reverse=True)

    return unique_numbers[1]

# Q8. Remove duplicates while preserving order
def remove_duplicates(numbers):
    unique_numbers = []

    for num in numbers:
        if num not in unique_numbers:
            unique_numbers.append(num)

    return unique_numbers

# Q9. Find the missing number

def find_missing_number(numbers):
    n = len(numbers) + 1

    expected_sum = n * (n + 1) // 2
    actual_sum = sum(numbers)

    return expected_sum - actual_sum

# Q10. Find the first pair whose sum equals the target

def first_pair_sum(numbers, target):
    seen = set()
    for num in numbers:
        complement = target - num

        if complement in seen:
            return (complement, num)

        seen.add(num)
    return None
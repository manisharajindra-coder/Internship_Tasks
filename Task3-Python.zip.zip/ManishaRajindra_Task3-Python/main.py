from solutions import word_frequency
input_sentence ="python is easy and python is powerful"
result = word_frequency(input_sentence)
print(result)

#character frequency 
from solutions import char_frequency
print("Q2:", char_frequency("programming"))
print("Q2 Test:", char_frequency("hello"))

#first non repeating character
from solutions import first_non_repeating_char
print("Q3 Output:", first_non_repeating_char("swiss"))

#are anagrams
from solutions import are_anagrams
print("Q4 Output:", are_anagrams("listen", "silent"))

#first repeating character
from solutions import first_repeating_char
print("Q5 Output:", first_repeating_char("programming"))


#move zeros to end
from solutions import move_zeros
print("Q6 Output:", move_zeros([0, 1, 0, 3, 12]))

#find second highest number
from solutions import second_highest
print("Q7 Output:", second_highest([10, 5, 8, 20, 20]))

#removing duplicates
from solutions import remove_duplicates
print("Q8 Output:", remove_duplicates([1, 2, 2, 3, 1, 4]))

from solutions import find_missing_number
print("Q9 Output:", find_missing_number([1, 2, 4, 5]))

#pair whose sum equals target
from solutions import first_pair_sum

numbers = [2, 7, 11, 15]

target = 9

print("Q10 Output:", first_pair_sum(numbers, target))